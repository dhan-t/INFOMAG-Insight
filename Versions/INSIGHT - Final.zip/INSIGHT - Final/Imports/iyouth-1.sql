-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2024 at 11:31 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iyouth`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(255) NOT NULL COMMENT 'Unique ID for address',
  `region` varchar(255) NOT NULL COMMENT 'Region where resident lives',
  `province` varchar(255) NOT NULL COMMENT 'Province where resident lives',
  `municipality` varchar(255) NOT NULL COMMENT 'Municipality where resident lives',
  `barangay` int(3) NOT NULL COMMENT 'Barangay number where resident lives',
  `zone` int(5) NOT NULL COMMENT 'Zone number where resident lives',
  `house_num` int(3) NOT NULL COMMENT 'House Number of Resident',
  `district` varchar(4) NOT NULL COMMENT 'District where resident lives'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address_id`, `region`, `province`, `municipality`, `barangay`, `zone`, `house_num`, `district`) VALUES
(3416783, 'National Capital Region', 'Metro Manila', 'City Of Manial', 337, 34, 1678, '3'),
(341616309, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1616, '3'),
(341652314, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1652, '3'),
(341663308, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1663, '3'),
(341671312, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1671, '3'),
(341680303, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1680, '3'),
(341680304, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1680, '3'),
(341692315, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1692, '3'),
(341692316, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1692, '3'),
(341692318, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1692, '3'),
(341708313, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1708, '3'),
(341711310, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1711, '3'),
(341711311, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1711, '3'),
(341713320, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1713, '3'),
(341721301, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1721, '3'),
(341722302, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1722, '3'),
(341745305, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1745, '3'),
(341745306, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1745, '3'),
(341745307, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1745, '3'),
(341748317, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1748, '3'),
(341748319, 'National Capital Region ', 'Metro Manila', 'City Of Manila', 337, 34, 1748, '3');

-- --------------------------------------------------------

--
-- Table structure for table `brgy. credentials`
--

CREATE TABLE `brgy. credentials` (
  `credentials_id` int(2) NOT NULL COMMENT 'Unique ID number for admin',
  `res_id` varchar(12) CHARACTER SET latin1 NOT NULL COMMENT 'Unique resident ID for admin',
  `username` varchar(255) NOT NULL COMMENT 'Unique username for admin',
  `password` varchar(255) NOT NULL COMMENT 'Unique password for admin',
  `clearance_lvl` int(2) NOT NULL COMMENT 'Level of clearance depending on admin',
  `salt` varchar(255) NOT NULL COMMENT 'Salt for hash security'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brgy. credentials`
--

INSERT INTO `brgy. credentials` (`credentials_id`, `res_id`, `username`, `password`, `clearance_lvl`, `salt`) VALUES
(1, '2024-3370011', 'admin', '$2a$10$qxNugYrFv2EYBljxY1gGJe2753c92da81e5db73e6911d10f154374577e6d5f', 2, '$2a$10$qxNugYrFv2EYBljxY1gGJe'),
(2, '2024-3370001', 'user', '$2a$10$Ey1AaWlh7DbGoi0IBDy8se2753c92da81e5db73e6911d10f154374577e6d5f', 1, '$2a$10$Ey1AaWlh7DbGoi0IBDy8se');

-- --------------------------------------------------------

--
-- Table structure for table `demographic`
--

CREATE TABLE `demographic` (
  `demo_id` int(11) NOT NULL COMMENT 'Unique ID for demographic',
  `civil_stat` varchar(255) NOT NULL COMMENT 'Civil Status of Resident',
  `youthAge_grp` varchar(20) NOT NULL COMMENT 'Youth Age Group of resident (Child Youth, Core Youth, \r\nYoung Adult)',
  `educ_background` varchar(255) NOT NULL COMMENT 'Educational Attainment of Resident',
  `youth_class` varchar(255) NOT NULL COMMENT 'Youth Class of Resident (In School Youth, Out School Youth, Working Youth)',
  `work_stat` varchar(255) NOT NULL COMMENT 'Work Status of Resident',
  `reg_SKVoter` varchar(3) NOT NULL COMMENT 'Is Resident a registered SKVoter',
  `reg_natVoter` varchar(3) NOT NULL COMMENT 'Is Resident a registered National Voter '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demographic`
--

INSERT INTO `demographic` (`demo_id`, `civil_stat`, `youthAge_grp`, `educ_background`, `youth_class`, `work_stat`, `reg_SKVoter`, `reg_natVoter`) VALUES
(111111, 'Single', 'Core youth', 'Elementary', 'Child Youth', 'Employed', 'Yes', 'Yes'),
(111121, 'Single', 'Core youth', 'Elementary', 'Child Youth', 'Employed', 'No', 'Yes'),
(211111, 'Single', 'Core youth', 'Elementary', 'Child Youth', 'Employed', 'Yes', 'Yes'),
(11100004, 'Single', 'Child Youth', 'High School Level', 'In School Youth', 'Unemployed', 'No', 'No'),
(11100016, 'Single', 'child Youth', 'High School Level', 'In School Youth', 'Unemployed', 'No', 'No'),
(11101006, 'Single', 'Child Youth', 'High School Level', 'In School Youth', 'Unemployed', 'Yes', 'No'),
(11101018, 'Single ', 'Child Youth', 'High School Level', 'In School Youth', 'Unemployed', 'Yes', 'No'),
(11110107, 'Single', 'Child Youth', 'High School Grad', 'In School Youth', 'Unemployed', 'No', 'No'),
(12100013, 'Single', 'Core Youth', 'elementary level', 'In School Youth', 'Unemployed', 'No', 'No'),
(12101103, 'Single', 'Core Youth', 'College Level', 'In School Youth', 'Unemployed', 'Yes', 'Yes'),
(12101105, 'Single ', 'Core Youth', 'College Level', 'In School Youth', 'Unemployed', 'Yes', 'Yes'),
(12101111, 'Single', 'core youth', 'College level', 'In School Youth', 'Unemployed', 'Yes', 'Yes'),
(12101115, 'Single', 'Core Youth', 'College level', 'In School Youth', 'Unemployed', 'Yes', 'Yes'),
(12110014, 'Single', 'Core Youth', 'High School Level', 'In School Youth', 'Self Employed', 'No', 'No'),
(12121101, 'Single', 'Core Youth', 'College Level', 'In School Youth', 'Self- Employed ', 'Yes', 'Yes'),
(12201120, 'Single', 'Core Youth', 'Collage Level', 'Out School Youth', 'Unemployed', 'Yes', 'Yes'),
(12411110, 'Single', 'Core youth', 'College Grad', 'Working Youth', 'Employed', 'Yes', 'Yes'),
(12420019, 'Single ', 'Core Youth', 'Collage Level', 'Working Youth', 'Employed', 'No', 'No'),
(12421117, 'Single', 'core youth', 'College Grad', 'Working Youth', 'Employed', 'Yes', 'Yes'),
(13411109, 'Single', 'Young adult', 'College Grad', 'Working Youth', 'Self Employed', 'Yes', 'Yes'),
(13411112, 'Single', 'Young Adult', 'High school grad ', 'working Youth', 'Self Employed', 'Yes', 'Yes'),
(13421102, 'Single', 'Young Adult', 'College Level', 'working Youth', 'employed', 'Yes', 'Yes'),
(13421108, 'Single', 'Young adult', 'College Grad', 'Working Youth', 'Employed', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `resident`
--

CREATE TABLE `resident` (
  `res_id` varchar(12) NOT NULL COMMENT 'Unique Resident ID',
  `first_name` varchar(255) NOT NULL COMMENT 'Resident First Name',
  `middle_initial` varchar(2) NOT NULL COMMENT 'Resident Middle Initial',
  `last_name` varchar(255) NOT NULL COMMENT 'Resident Last Name',
  `birthdate` date NOT NULL COMMENT 'Resident Birthdate (YY-MM-DD)',
  `sex` enum('M','F') NOT NULL COMMENT 'Resident Sexuality',
  `contact_num` bigint(11) NOT NULL COMMENT 'Residents Contact Number',
  `email` varchar(255) DEFAULT NULL COMMENT 'Resident Email',
  `address_id` int(255) NOT NULL COMMENT 'Unique ID for address',
  `demo_id` int(11) NOT NULL COMMENT 'Unique ID for demographic'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resident`
--

INSERT INTO `resident` (`res_id`, `first_name`, `middle_initial`, `last_name`, `birthdate`, `sex`, `contact_num`, `email`, `address_id`, `demo_id`) VALUES
('2024-3370001', 'robbie', 'D', 'padilla', '2003-10-01', 'M', 9284921982, 'test@gmail.com', 341748319, 12421117),
('2024-3370011', 'Lila', 'J', 'Carney', '2000-03-23', 'F', 9273963743, 'Jewdpajes@gmail.com', 341711310, 12411110),
('2024-3370118', 'Evelyn', 'Q', 'Marsh', '2001-09-06', 'F', 9151198642, 'Hersheykimpastranacollados@gmail.com', 341748317, 12421117),
('2024-3370212', 'Jonathon', 'K', 'Lucero', '2002-10-11', 'M', 9563911766, 'Ranzpajes@gmail.com', 341711311, 12101111),
('2024-3370303', 'Madeleine', 'C', 'Evans', '2003-11-18', 'F', 9458056082, 'gwynarbo@gmail.com', 341680303, 12101103),
('2024-3370305', 'Troy', 'E', 'Whitehead', '2003-01-10', 'M', 9973168468, 'raymundoflores3r@gmail.com', 341745305, 12101105),
('2024-3370319', 'Johnathan', 'S', 'Jennings', '2003-07-13', 'M', 0, 'N/A', 341748319, 12420019),
('2024-3370320', 'Christopher', 'T', 'Kelly', '2003-05-11', 'M', 9602855720, 'Ivanageloocampo234@gmail.com', 341713320, 12201120),
('2024-3370401', 'Deshawn', 'A', 'House', '2004-07-12', 'M', 9533608845, 'dacanaylyndoncypher@gmail.com', 341721301, 12121101),
('2024-3370416', 'Nadia', 'O', 'King', '2004-03-15', 'F', 0, 'Tamayo@gmail.com', 341692315, 12101115),
('2024-3370514', 'Tyler', 'M', 'Berger', '2005-07-14', 'M', 9691747436, 'N/A', 341708313, 12100013),
('2024-3370615', 'Marian', 'N', 'Rosario', '2006-01-06', 'F', 9455739277, 'N/A', 341652314, 12110014),
('2024-3370619', 'Barry', 'R', 'Wilkerson', '2006-10-30', 'M', 0, 'ramcama@gmail.com', 341692318, 11101018),
('2024-3370704', 'Maximo', 'D', 'Hammond', '2007-06-16', 'M', 9277631615, 'marcusirvingarbo@gmail.com', 341680304, 11100004),
('2024-3370706', 'Johnny', 'F', 'Elliott', '2007-10-21', 'M', 0, 'N/A', 341745306, 11101006),
('2024-3370807', 'Hipolito', 'G', 'Ponce', '2008-07-12', 'M', 9933303425, 'Musnikervingabriel@gmail.com', 341745307, 11110107),
('2024-3370817', 'Effie', 'P', 'Nichols', '2008-09-14', 'F', 0, 'Maeaustria06@gmail.com', 341692316, 11100016),
('2024-337891', 'robybyby', 'i', 'padilalala', '1989-10-01', 'M', 123456789, ' robybyby@gmail.com', 341616309, 111111),
('2024-3379413', 'Dorthy', 'L', 'Moore', '1994-09-08', 'F', 9058717026, 'carolsolomon29@gmail.com', 341671312, 13411112),
('2024-3379602', 'Marlon', 'B', 'Sharp', '1996-11-11', 'M', 9657266536, 'dacanaymarkbenedict@gmail.com', 341722302, 13421102),
('2024-3379608', 'Deena', 'H', 'Reese', '1996-08-07', 'F', 0, 'N/A', 341663308, 13421108),
('2024-3379709', 'Laurel', 'I', 'Blankenship', '1997-09-06', 'F', 0, 'N/A', 341616309, 13411109);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`);

--
-- Indexes for table `brgy. credentials`
--
ALTER TABLE `brgy. credentials`
  ADD PRIMARY KEY (`credentials_id`),
  ADD KEY `res_id` (`res_id`);

--
-- Indexes for table `demographic`
--
ALTER TABLE `demographic`
  ADD PRIMARY KEY (`demo_id`);

--
-- Indexes for table `resident`
--
ALTER TABLE `resident`
  ADD PRIMARY KEY (`res_id`),
  ADD UNIQUE KEY `address_id` (`address_id`,`demo_id`),
  ADD KEY `res-demo` (`demo_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `brgy. credentials`
--
ALTER TABLE `brgy. credentials`
  ADD CONSTRAINT `brgy. credentials_ibfk_1` FOREIGN KEY (`res_id`) REFERENCES `resident` (`res_id`);

--
-- Constraints for table `resident`
--
ALTER TABLE `resident`
  ADD CONSTRAINT `res-add` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`),
  ADD CONSTRAINT `res-demo` FOREIGN KEY (`demo_id`) REFERENCES `demographic` (`demo_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
